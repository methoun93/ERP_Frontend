export const environment = {
  production: false,
  //apiBaseUrl: 'http://172.16.61.225:8081/api',
  apiBaseUrl: 'https://localhost:5001/api',
};
