import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReportElement, ReportLayout } from '../models/reporting.models';

type BuilderTab = 'design' | 'template' | 'variant' | 'parameter' | 'theme' | 'image' | 'page';

@Component({
  selector: 'app-report-builder',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './report-builder.html',
  styleUrls: ['./report-builder.scss']
})
export class ReportBuilder {
  activeTab: BuilderTab = 'design';
  selectedElement?: ReportElement;
  reportName = 'Purchase Order Print';
  reportNo = 'MER-RPT-000001';
  reportKey = 'PO_PRINT';
  procedureName = 'rpt_Merchandising_OrderPrint';

  layout: ReportLayout = {
    pageSettings: {
      pageSize: 'A4',
      orientation: 'Portrait',
      marginTop: 12,
      marginRight: 12,
      marginBottom: 12,
      marginLeft: 12,
      showPageNo: true,
      showPrintDate: true,
      repeatHeader: true
    },
    theme: {
      primaryColor: '#0f766e',
      headerBackground: '#0f3b75',
      headerTextColor: '#ffffff',
      borderColor: '#cbd5e1',
      textColor: '#111827'
    },
    elements: [
      { id: 'txt-company', type: 'text', label: 'Company Name', text: 'Company Name', x: 240, y: 24, width: 260, height: 28, style: { fontSize: 20, fontWeight: 800 } },
      { id: 'txt-title', type: 'text', label: 'Report Title', text: 'PURCHASE ORDER', x: 255, y: 78, width: 230, height: 26, style: { fontSize: 18, fontWeight: 800 } },
      { id: 'img-logo', type: 'image', label: 'Logo', imageUrl: '/assets/logo.png', x: 52, y: 26, width: 72, height: 58 },
      { id: 'tbl-main', type: 'table', label: 'Main Table', x: 48, y: 210, width: 660, height: 160, columns: [
        { field: 'ItemCode', caption: 'Item Code', width: 90 },
        { field: 'ItemDescription', caption: 'Item Description', width: 190 },
        { field: 'Uom', caption: 'UOM', width: 70, align: 'center' },
        { field: 'Qty', caption: 'Qty', width: 80, align: 'right', aggregate: 'sum' },
        { field: 'Rate', caption: 'Rate', width: 80, align: 'right' },
        { field: 'Amount', caption: 'Amount', width: 100, align: 'right', aggregate: 'sum' }
      ] },
      { id: 'txt-signature', type: 'text', label: 'Signature', text: 'Authorized Signature', x: 560, y: 455, width: 150, height: 24 }
    ]
  };

  tools: Array<{ type: ReportElement['type']; label: string; icon: string }> = [
    { type: 'text', label: 'Text', icon: 'T' },
    { type: 'field', label: 'Field', icon: '{}' },
    { type: 'image', label: 'Image', icon: '▧' },
    { type: 'table', label: 'Table', icon: '▦' },
    { type: 'line', label: 'Line', icon: '─' },
    { type: 'rectangle', label: 'Rectangle', icon: '▭' },
    { type: 'barcode', label: 'Barcode', icon: '▥' },
    { type: 'qr', label: 'QR Code', icon: '▣' },
    { type: 'pageBreak', label: 'Page Break', icon: '↧' }
  ];

  parameters = [
    { parameterName: 'orderId', displayName: 'Order ID', dataType: 'Guid', controlType: 'Hidden', isRequired: true },
    { parameterName: 'buyerId', displayName: 'Buyer', dataType: 'Guid', controlType: 'Dropdown', isRequired: false },
    { parameterName: 'fromDate', displayName: 'From Date', dataType: 'Date', controlType: 'Date', isRequired: false },
    { parameterName: 'toDate', displayName: 'To Date', dataType: 'Date', controlType: 'Date', isRequired: false }
  ];

  variants = [
    { variantCode: 'DEFAULT', variantName: 'Default', isDefault: true },
    { variantCode: 'BUYER_COPY', variantName: 'Buyer Copy', isDefault: false },
    { variantCode: 'FACTORY_COPY', variantName: 'Factory Copy', isDefault: false }
  ];

  templates = [
    { templateName: 'Default Template', scope: 'All Company', isDefault: true },
    { templateName: 'Company A Template', scope: 'Company', isDefault: false },
    { templateName: 'Gazipur Area Template', scope: 'Area', isDefault: false }
  ];

  addElement(type: ReportElement['type']): void {
    const id = `${type}-${Date.now()}`;
    const element: ReportElement = { id, type, label: this.toTitle(type), text: this.toTitle(type), x: 80, y: 120, width: type === 'table' ? 560 : 160, height: type === 'table' ? 120 : 32 };
    if (type === 'table') element.columns = [{ field: 'Field1', caption: 'Column 1', width: 120 }];
    this.layout.elements.push(element);
    this.selectedElement = element;
  }

  selectElement(element: ReportElement): void {
    this.selectedElement = element;
  }

  saveLayout(): void {
    const json = JSON.stringify(this.layout, null, 2);
    console.log('LayoutJson', json);
    alert('Layout JSON generated. Connect this save action with Rpt_ReportTemplates API.');
  }

  printPreview(): void {
    window.print();
  }

  private toTitle(value: string): string {
    return value.replace(/([A-Z])/g, ' $1').replace(/^./, x => x.toUpperCase());
  }
}
